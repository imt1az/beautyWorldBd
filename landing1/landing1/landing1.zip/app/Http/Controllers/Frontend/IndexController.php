<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function Index(){
      
        $services = Service::latest()->get();

        return view('frontend.index');
    }

    public function ServiceDetails($id){
        $service = Service::findOrFail($id);

        return view('frontend.service.service_details',compact('service'));
    }
}
