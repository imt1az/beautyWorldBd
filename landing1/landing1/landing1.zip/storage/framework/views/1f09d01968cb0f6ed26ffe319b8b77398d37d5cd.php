
<?php $__env->startSection('admin'); ?>
    
    <div class="content ">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12 mb-3">
                    <div class="page-title-box ">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <a href="<?php echo e(route('add.service.post')); ?>" class="btn btn-blue waves-effect waves-light">Add
                                    Service
                                    Post</a>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->


            <!-- end row-->

            <div class="row">
                <div class="col-12">
                    <div class="card overflow-auto w-100">
                        <div class="card-body">


                            <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>Sl</th>
                                        <th>Title </th>
                                        <th>Description </th>




                                        <th>Action </th>
                                    </tr>
                                </thead>


                                <tbody class="">

                                    <?php $__currentLoopData = $allService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>

                                            <td><?php echo e(Str::limit($item->title, 20)); ?></td>
                                            <td><?php echo e(Str::limit($item->description, 20)); ?></td>







                                            <td>
                                                <a href="<?php echo e(route('edit.service.post', $item->id)); ?>"
                                                    class="btn btn-primary rounded-pill waves-effect waves-light">Edit</a>



                                                <a href="<?php echo e(route('delete.service.post', $item->id)); ?>"
                                                    class="btn btn-danger rounded-pill waves-effect waves-light"
                                                    id="delete">Delete</a>

                                             

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div> <!-- end card body-->
                    </div> <!-- end card -->
                </div><!-- end col-->
            </div>
            <!-- end row-->



        </div> <!-- container -->

    </div> <!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landing1\resources\views/backend/service/all_service_post.blade.php ENDPATH**/ ?>