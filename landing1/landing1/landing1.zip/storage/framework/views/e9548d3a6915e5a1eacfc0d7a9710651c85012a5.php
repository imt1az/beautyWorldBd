
<?php $__env->startSection('admin'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">

                                <li class="breadcrumb-item active">Add News Post</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Add News Post</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <!-- Form row -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <form id="myForm" method="post" action="<?php echo e(route('update.news.post')); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($news->id); ?>">

                                <div class="row">
                                    <div class="form-group col-md-6 mb-3">
                                        <label for="inputEmail4" class="form-label">Category Name</label>

                                        <select name="category_id" id="heard" class="form-select parsley-success"
                                            required="" data-parsley-id="21">
                                            <option value="">Choose..</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option selected value="<?php echo e($item->id); ?>"><?php echo e($item->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <ul class="parsley-errors-list" id="parsley-id-21" aria-hidden="true"></ul>
                                        
                                    </div>


                               

                                    <div class="form-group col-md-6 mb-3">
                                        <label for="inputEmail4" class="form-label">News Title </label>
                                        <input type="text" value="<?php echo e($news->news_title); ?>" name="news_title" class="form-control" id="inputEmail4">
                                    </div>
                                    
                                    <div class="form-group col-md-6 mb-3">
                                        <label class="form-label">Thumbnail Image</label>
                                        <input type="file" id='image' name="image" class="form-control">
                                    </div>

                                    <div class="form-group col-md-6 mb-3">
                                        <label for="example-fileinput" class="form-label"></label>
                                        <img id='showImage' src="<?php echo e(url('upload/no_image.jpg')); ?>"
                                            class="rounded-circle avatar-lg img-thumbnail" alt="profile-image">
                                    </div>
                                    

                                    <div class="col-lg-6 mb-3">
                                        <div>
                                            <label class="form-label">News Tags</label>
                                            <label for="inputEmail4" class="form-label">Tags </label>
                                            <input type="text" name="tags" class="selectize-close-btn" value="Feni">

                                        </div>
                                    </div>
                                    <div class="row mb-3" id="preview_img"></div>

                                    <div class="form-group col-md-6 col-md-12 mb-3">
                                        <label for="inputEmail4" class="form-label">News Details</label>
                                        <textarea name="news_details"><?php echo $news->news_details; ?></textarea>
                                    </div>
                            


                                </div>



                                <button type="submit" class="btn btn-primary waves-effect waves-light">Save
                                    Changes</button>

                            </form>

                        </div> <!-- end card-body -->
                    </div> <!-- end card-->
                </div> <!-- end col -->
            </div>
            <!-- end row -->



        </div> <!-- container -->

    </div> <!-- content -->

    

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            })
        })
    </script>

    

    

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landing1\resources\views/backend/news/edit_news.blade.php ENDPATH**/ ?>