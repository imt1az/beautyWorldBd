

<?php $__env->startSection('home'); ?>
    <style>
        .blog .sidebar .recent-posts h4 {
            margin-left: 0px !important;
        }
    </style>

    <section class="breadcrumbs">
        <div class="container">

            <ol>
                <li><a href="https://shanguinfotech.com">HOME</a></li>
                <li>SERVICE</li>
            </ol>
            <h5><?php echo e($service->title); ?></h5>

        </div>
    </section>

    <!-- ======= Hero Section ======= -->
    <style>
        section {
            padding: 20px 0 !important;
        }

        .swiper-pagination-bullet-active {
            color: #015754 !important;
            background: #015754 !important;
        }
    </style>

    <section id="blog" class="blog">
        <div class="container aos-init aos-animate" data-aos="fade-up">

            <div class="row">

                <div class="col-lg-8 entries">

                    <article class="entry entry-single text-center">



                        <h2 class="entry-title">
                            <a href="javascript:void(0)"><?php echo e($service->title); ?></a>
                        </h2>

                        <div class="entry-content">
                            <p>
                            </p>
                            <p style="text-align: justify;"><?php echo $service->description; ?></p>
                           

                            
                        </div>

                    </article><!-- End blog entry -->

                </div><!-- End blog entries list -->

                <div class="col-lg-4">

                    <div class="sidebar">

                        <h3 class="sidebar-title">OTHER SERVICES</h3>
                        <hr>
                        <div class="sidebar-item recent-posts">
                            <?php
                            $services = App\Models\Service::latest()->get();
                       ?>

                       <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="post-item">
                        <ul>
                            <li>
                                <h4><a href="<?php echo e(route('sevice.details',$item->id)); ?>"><?php echo e($item->title); ?></a></h4>
                            </li>
                        </ul>

                    </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            

                        </div><!-- End sidebar recent posts-->

                    </div><!-- End sidebar -->

                </div><!-- End blog sidebar -->

            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.home_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landing1\landing1\resources\views/frontend/service/service_details.blade.php ENDPATH**/ ?>