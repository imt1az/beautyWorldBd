
<?php $__env->startSection('admin'); ?>
    
    <div class="content ">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12 mb-3">
                    <div class="page-title-box ">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <a href="<?php echo e(route('add.news.post')); ?>" class="btn btn-blue waves-effect waves-light">Add News
                                    Post</a>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

           
            <!-- end row-->

            <div class="row">
                <div class="col-12">
                    <div class="card overflow-auto w-100">
                        <div class="card-body">


                            <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>Sl</th>
                                        <th>Image </th>
                                        <th>Title </th>
                                        <th>Category </th>
                                   
                                 
                                      
                                        <th>Action </th>
                                    </tr>
                                </thead>


                                <tbody class="">
                                 
                                    <?php $__currentLoopData = $allNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><img src="<?php echo e(asset($item->image)); ?> " style="width: :50px; height:50px;">
                                        </td>
                                        <td><?php echo e(Str::limit($item->news_title, 20)); ?></td>
                                        <?php if($item->category_id == null): ?>
                                            <td> </td>
                                        <?php else: ?>
                                            <td><?php echo e($item['category']['category_name']); ?></td>
                                        <?php endif; ?>
                                        



                                        





                                        <td>
                                            <a href="<?php echo e(route('edit.newspost', $item->id)); ?>"
                                                class="btn btn-primary rounded-pill waves-effect waves-light">Edit</a>



                                            <a href="<?php echo e(route('delete.newspost', $item->id)); ?>"
                                                class="btn btn-danger rounded-pill waves-effect waves-light"
                                                id="delete">Delete</a>

                                            <?php if($item->special == 1): ?>
                                                <a href="<?php echo e(route('nonspecial.newspost', $item->id)); ?>"
                                                    class="btn rounded-pill waves-effect "><i class='fas fa-bell'
                                                        style='font-size:20px;color:green'></i></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('special.newspost', $item->id)); ?>"
                                                    class="btn rounded-pill waves-effect"><i class='fas fa-bell-slash'
                                                        style='font-size:20px;color:red'></i></a>
                                            <?php endif; ?>





                                            <?php if($item->status == 1): ?>
                                                <a href="<?php echo e(route('inactive.news.post', $item->id)); ?>"
                                                    class="btn btn-primary rounded-pill waves-effect waves-light"
                                                    title="Inactive"><i class="fas fa-thumbs-up"></i></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('active.news.post', $item->id)); ?>"
                                                    class="btn btn-primary rounded-pill waves-effect waves-light"
                                                    title="Active"><i class="fas fa-thumbs-down"></i></i></a>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div> <!-- end card body-->
                    </div> <!-- end card -->
                </div><!-- end col-->
            </div>
            <!-- end row-->



        </div> <!-- container -->

    </div> <!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landing1\landing1\resources\views/backend/news/all_news_post.blade.php ENDPATH**/ ?>