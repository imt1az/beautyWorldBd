
<?php $__env->startSection('admin'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">

                                <li class="breadcrumb-item active">Add News Post</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Add News Post</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <!-- Form row -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <form id="myForm" method="post" action="<?php echo e(route('update.testi.post')); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($testi->id); ?>">

                                <div class="row">
                                   


                               

                                    <div class="form-group col-md-6 mb-3">
                                        <label for="inputEmail4" class="form-label">Name</label>
                                        <input type="text" value="<?php echo e($testi->name); ?>" name="name" class="form-control" id="inputEmail4">
                                    </div>
                                    
                                    <div class="form-group col-md-6 mb-3">
                                        <label class="form-label">Thumbnail Image</label>
                                        <input type="file" id='image' name="image" class="form-control">
                                    </div>

                                    <div class="form-group col-md-6 mb-3">
                                        <label for="example-fileinput" class="form-label"></label>
                                        <img id='showImage' src="<?php echo e(url('upload/no_image.jpg')); ?>"
                                            class="rounded-circle avatar-lg img-thumbnail" alt="profile-image">
                                    </div>
                                    

                               
                                    <div class="row mb-3" id="preview_img"></div>

                                    <div class="form-group col-md-6 mb-3">
                                        <label for="inputEmail4" class="form-label">Designation</label>
                                        <input type="text" value="<?php echo e($testi->designation); ?>" name="designation" class="form-control" id="inputEmail4">
                                    </div>

                                    <div class="form-group col-md-6 col-md-12 mb-3">
                                        <label for="inputEmail4" class="form-label">Details</label>
                                        <textarea name="details"><?php echo $testi->details; ?></textarea>
                                    </div>
                            


                                </div>



                                <button type="submit" class="btn btn-primary waves-effect waves-light">Save
                                    Changes</button>

                            </form>

                        </div> <!-- end card-body -->
                    </div> <!-- end card-->
                </div> <!-- end col -->
            </div>
            <!-- end row -->



        </div> <!-- container -->

    </div> <!-- content -->

    

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            })
        })
    </script>

    

    

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landing1\resources\views/backend/testimonial/edit_testi.blade.php ENDPATH**/ ?>