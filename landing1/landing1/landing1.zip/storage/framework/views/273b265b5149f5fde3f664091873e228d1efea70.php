
<?php $__env->startSection('admin'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">

                                <li class="breadcrumb-item active">Add News Post</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Add News Post</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <!-- Form row -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <form id="myForm" method="post" action="<?php echo e(route('store.service.post')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                   


                               

                                    <div class="form-group col-md-6 mb-3">
                                        <label for="inputEmail4" class="form-label">Service Title </label>
                                        <input type="text" name="title" class="form-control" id="inputEmail4">
                                    </div>
                                  

                                  

                             
                          

                                    <div class="form-group col-md-6 col-md-12 mb-3">
                                        <label for="inputEmail4" class="form-label">Service Details</label>
                                        <textarea  name="description"></textarea>
                                    </div>
                            


                                </div>



                                <button type="submit" class="btn btn-primary waves-effect waves-light">Save
                                    Changes</button>

                            </form>

                        </div> <!-- end card-body -->
                    </div> <!-- end card-->
                </div> <!-- end col -->
            </div>
            <!-- end row -->



        </div> <!-- container -->

    </div> <!-- content -->

    

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            })
        })
    </script>

    

    

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landing1\resources\views/backend/service/add_service_post.blade.php ENDPATH**/ ?>